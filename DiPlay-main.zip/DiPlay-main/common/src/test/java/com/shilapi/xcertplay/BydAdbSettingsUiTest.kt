package com.shilapi.xcertplay

import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.shilapi.xcertplay.adb.LocalAdb
import com.shilapi.xcertplay.host.R
import com.shilapi.xcertplay.hud.BydOutputSettings
import com.shilapi.xcertplay.hud.BydVehicleFieldStore
import com.shilapi.xcertplay.vehicle.VehiclePlatforms
import com.shilapi.xcertplay.network.CarHotspotSettings
import com.shilapi.xcertplay.orchestration.WirelessHotspotMode
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.util.ReflectionHelpers

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29], qualifiers = "en", manifest = Config.NONE)
class BydAdbSettingsUiTest {
    private lateinit var activity: DiPlayActivity
    private lateinit var controls: LinearLayout

    @Before fun setUp() {
        val app = RuntimeEnvironment.getApplication()
        for (name in listOf("diplay_byd_outputs", "diplay_byd_vehicle_fields", "diplay_car_hotspot", "xcertplay_airplay")) {
            app.getSharedPreferences(name, 0).edit().clear().commit()
        }
        BydVehicleFieldStore.clearMemoryForTests()
        // Platform detection is cached per process, and Robolectric reuses one JVM across test
        // classes. A class that ran earlier may have cached a different head unit, so the cache is
        // dropped here after the packages below are in place.
        VehiclePlatforms.clearCacheForTests()
        shadowOf(app.packageManager).removePackage("com.byd.amapservice")
        shadowOf(app.packageManager).installPackage(PackageInfo().apply {
            packageName = "com.byd.carsettings"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.byd.carsettings"
                flags = ApplicationInfo.FLAG_SYSTEM
            }
        })
        activity = Robolectric.buildActivity(DiPlayActivity::class.java).get()
        activity.setTheme(android.R.style.Theme_Material_NoActionBar)
        AirPlayPersistence.saveWirelessHotspotMode(activity, WirelessHotspotMode.MANUAL)
        controls = LinearLayout(activity)
        assertTrue(CarHotspotSetup.isBydHeadUnit(activity))
        assertFalse(BydOutputSettings.navigationAvailable(activity))
    }

    @Test fun hotspotAndVehicleSettingsHaveOneOwnerWithoutNavigationServices() {
        render(LocalAdb.Access.READY)
        val advanced = advancedVehicleData()
        val page = LinearLayout(activity).apply { addView(controls); addView(advanced) }
        assertEquals(View.VISIBLE, controls.visibility)
        assertEquals(1, switches(controls).size)
        assertFalse(CarHotspotSettings.enabled(activity))
        for (id in listOf(R.string.car_battery_for_the_iphone, R.string.wheel_speed_for_tunnels,
            R.string.video_while_parked, R.string.auto_car_hotspot_title)) {
            assertEquals(1, switches(page).count { it.contentDescription == activity.getString(id) })
        }
        assertEquals(1, labels(page).count { it == activity.getString(R.string.check_adb_access) })
        assertTrue(labels(advanced).any { it.contains(activity.getString(R.string.vehicle_data_mode_default)) })
    }

    @Test fun unapprovedHotspotStillShowsItsOptInAndVehicleSettingsRemainAvailable() {
        render(LocalAdb.Access.NOT_APPROVED)
        assertEquals(View.VISIBLE, controls.visibility)
        assertTrue(labels(controls).contains(activity.getString(R.string.adb_not_approved)))
        assertEquals(1, switches(controls).size)
        assertTrue(labels(advancedVehicleData()).contains(activity.getString(R.string.check_adb_access)))
    }

    @Test fun changingHotspotModeHidesOnlyHotspotControlsAndPreservesTheSavedChoice() {
        CarHotspotSettings.setEnabled(activity, true)
        AirPlayPersistence.saveAutoStartOnBoot(activity, true)
        for (mode in listOf(WirelessHotspotMode.MANUAL, WirelessHotspotMode.WIFI_P2P, WirelessHotspotMode.MANUAL)) {
            AirPlayPersistence.saveWirelessHotspotMode(activity, mode)
            render(LocalAdb.Access.READY)
            assertEquals(if (mode == WirelessHotspotMode.MANUAL) View.VISIBLE else View.GONE, controls.visibility)
            assertEquals(mode == WirelessHotspotMode.MANUAL, labels(controls).contains(activity.getString(R.string.auto_car_hotspot_title)))
            assertEquals(3, switches(advancedVehicleData()).size)
            assertTrue(CarHotspotSettings.enabled(activity))
            assertTrue(AirPlayPersistence.loadAutoStartOnBoot(activity))
        }
    }

    @Test fun unavailableHotspotAdbDoesNotHideTheVehicleModeOrItsSavedSwitches() {
        BydOutputSettings.setBatteryToIphone(activity, true)
        for (access in listOf(LocalAdb.Access.UNREACHABLE, LocalAdb.Access.UNSUPPORTED)) {
            render(LocalAdb.Access.READY)
            render(access)
            assertEquals(View.GONE, controls.visibility)
            assertEquals(0, controls.childCount)
            assertNull(ReflectionHelpers.getField<TextView?>(activity, "adbStatus"))
            assertTrue(switches(advancedVehicleData()).single {
                it.contentDescription == activity.getString(R.string.car_battery_for_the_iphone)
            }.isChecked)
        }
    }

    @Test fun hotspotAuthorizationDisablesVehicleChoicesWithoutChangingPreferences() {
        ReflectionHelpers.setField(activity, "adbSwitchChangePending", true)
        val advanced = advancedVehicleData()
        assertTrue(switches(advanced).all { !it.isEnabled })
        assertFalse(descendants(advanced).filterIsInstance<TextView>().single {
            it.text.startsWith(activity.getString(R.string.vehicle_data_mode) + " · ")
        }.isEnabled)
        assertFalse(BydOutputSettings.legacyVehicleProbe(activity))
        assertFalse(BydOutputSettings.batteryToIphone(activity))
    }

    private fun advancedVehicleData() = LinearLayout(activity).also {
        ReflectionHelpers.callInstanceMethod<Unit>(activity, "advancedVehicleData",
            ReflectionHelpers.ClassParameter.from(LinearLayout::class.java, it))
    }
    private fun render(access: LocalAdb.Access) {
        ReflectionHelpers.callInstanceMethod<Unit>(activity, "renderBydAdbControls",
            ReflectionHelpers.ClassParameter.from(LinearLayout::class.java, controls),
            ReflectionHelpers.ClassParameter.from(LocalAdb.Access::class.java, access))
    }
    private fun descendants(view: View): List<View> = buildList {
        add(view)
        if (view is ViewGroup) for (index in 0 until view.childCount) addAll(descendants(view.getChildAt(index)))
    }
    private fun labels(view: View) = descendants(view).filterIsInstance<TextView>().map { it.text.toString() }
    private fun switches(view: View) = descendants(view).filterIsInstance<Switch>()
}
